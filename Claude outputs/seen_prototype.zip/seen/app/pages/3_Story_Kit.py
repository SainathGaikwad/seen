"""S4 — Story kit: one verified event, eight formats, with the claim checker in front of publication."""
import json

import streamlit as st

from common import data_banner, inject_css, load_csv, load_kit, require_run, save_kit

from seen.stories import claim_check
from seen.stories.compiler import FORMATS, GUIDANCE_MARKER, run_checks

st.set_page_config(page_title="SEEN — Story kit", page_icon="🏏", layout="wide")
inject_css()
st.title("Story kit")
data_banner()

LABELS = {"video_script": "60-second video script", "social_posts": "Social posts", "article": "Article", "infographic": "Infographic (spec)",
          "creator_brief": "Creator brief", "commentator_note": "Commentator note", "quiz": "Fan quiz", "sponsor_hook": "Sponsor hook"}

if require_run():
    xi = load_csv("unseen_xi.csv")
    if xi.empty:
        st.stop()
    names = xi["name"].tolist()
    pre = st.session_state.get("selected_player")
    default = xi[xi.player_id == pre]["name"].iloc[0] if pre in set(xi.player_id) else names[0]
    pick = st.selectbox("Athlete (Unseen XI)", names, index=names.index(default))
    pid = xi[xi.name == pick].iloc[0].player_id
    st.session_state["selected_player"] = pid
    kit = load_kit(pid)
    if not kit:
        st.warning("No kit for this athlete yet.")
        st.stop()

    st.markdown(f"**{kit['headline']}**  ·  pattern `{kit['pattern']}`  ·  generated in `{kit['mode']}` mode")
    passed = sum(1 for v in kit["checks"].values() if v["passed"])
    st.progress(passed / len(kit["checks"]), text=f"Claim checker: {passed}/{len(kit['checks'])} formats verified")

    tabs = st.tabs([LABELS[f] for f in FORMATS])
    for tab, fmt in zip(tabs, FORMATS):
        with tab:
            text = kit["formats"][fmt]
            body, _, guidance = text.partition(GUIDANCE_MARKER)
            if fmt in ("infographic", "quiz"):
                st.code(body, language="json")
            else:
                edited = st.text_area("Edit (every number must still match a fact)", body, height=260, key=f"ta_{pid}_{fmt}")
                if guidance:
                    st.caption("Guidance (not checked as claims): " + guidance.replace("\n", " · "))
                cols = st.columns([1, 1, 1.4, 2.6])
                if cols[0].button("Re-check", key=f"chk_{pid}_{fmt}"):
                    kit.setdefault("generated", {}).setdefault(fmt, text)   # keep the generated version so an edit can be undone
                    kit["formats"][fmt] = edited + (GUIDANCE_MARKER + guidance if guidance else "")
                    kit["checks"] = run_checks(kit)
                    save_kit(kit)
                    st.rerun()
                if cols[1].button("Approve", key=f"appr_{pid}_{fmt}", disabled=not kit["checks"][fmt]["passed"]):
                    kit.setdefault("approved", {})[fmt] = True
                    save_kit(kit)
                    st.success("Approved")
                original = (kit.get("generated") or {}).get(fmt)
                if original and original != text and cols[2].button("Revert edits", key=f"rev_{pid}_{fmt}", help="Restore the generated, verified text"):
                    kit["formats"][fmt] = original
                    kit["checks"] = run_checks(kit)
                    save_kit(kit)
                    st.rerun()
            ch = kit["checks"][fmt]
            st.markdown(f"<span class='{'ok' if ch['passed'] else 'bad'}'><b>{'PASS' if ch['passed'] else 'BLOCKED'}</b> — {ch['summary']}</span>", unsafe_allow_html=True)
            bad = [c for c in ch["claims"] if c["status"] == "unmatched"]
            if bad:
                st.error("Unverifiable numbers: " + ", ".join(sorted({c['text'] for c in bad})) + " — not in any fact. Fix the text or add a sourced fact.")
            if ch["banned"]:
                st.error("Banned topics: " + ", ".join(ch["banned"]))
            if ch.get("unknown_names"):
                st.caption("Names not in the fact bundle (warning): " + ", ".join(ch["unknown_names"]))
            if kit.get("rejected", {}).get(fmt):
                with st.expander("LLM draft rejected by the claim checker (kept the template instead)"):
                    st.write(kit["rejected"][fmt]["reason"])
                    st.code(kit["rejected"][fmt]["text"])

    with st.expander(f"Fact bundle ({len(kit['facts'])} facts)"):
        for f in kit["facts"]:
            st.markdown(f"<div class='fact'>[{f['id']}] {f['text']} — <i>{f['source']}</i></div>", unsafe_allow_html=True)

    st.divider()
    st.subheader("Try the checker: paste a sentence with a made-up number")
    demo = st.text_input("Sentence", f"{kit['name']} scored 97 runs and took 9 wickets in the tournament.")
    res = claim_check.check(demo, kit["facts"], [kit["name"], kit["team"]])
    st.markdown(f"<span class='{'ok' if res.passed else 'bad'}'><b>{'PASS' if res.passed else 'BLOCKED'}</b> — {res.summary()}</span>", unsafe_allow_html=True)
    if res.claims:
        import pandas as pd
        st.dataframe(pd.DataFrame([{"number in the sentence": c["text"], "status": c["status"], "matched fact": c.get("fact") or "—"} for c in res.claims]),
                     width="stretch", hide_index=True)
